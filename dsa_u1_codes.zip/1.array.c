#include<stdio.h>
#include"1.array.h"
int main(){
int n=SIZE;

for(int i=0;i<n;i++)
    scanf("%d",&a[i]);
printf("\n");
for(int i=0;i<n;i++)
    printf("%d ",a[i]);
return 0;
}
