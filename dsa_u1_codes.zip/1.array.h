# define SIZE 5
int a[SIZE];
