#include <stdio.h>
#include "2.structure.h"

int main(){
struct Example s1;
printf("\nEnter a,b,c");
scanf("%d %c %f",&s1.a,&s1.b,&s1.c);
printf("\na=%d b=%c c=%f",s1.a,s1.b,s1.c);
return 0;
}
