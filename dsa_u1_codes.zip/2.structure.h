struct Example{
    int a;
    char b;
    float c;
};
