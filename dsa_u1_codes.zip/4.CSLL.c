//Singly Linked List
#include<stdio.h>
#include<stdlib.h>

typedef struct node{
    int data;
    struct node *next;
}NODE;
NODE* createNode(int data){
    NODE *nn=(NODE*)malloc(sizeof(NODE));
    nn->data=data;
    nn->next=NULL;
    return nn;
}

NODE* insertStart(NODE* head,int data){
    NODE *nn,*t=head;
    if(head==NULL){ //List is Empty
        head=createNode(data);
        head->next=head;
        }
    else{
        while(t->next!=head)//change
            t=t->next;
         nn=createNode(data);
         nn->next=head;
         head=nn;
        t->next=head;//change
        }
    return head;
}
NODE* insertEnd(NODE* head,int data){
    NODE *nn,*temp=head;
    if(head==NULL) //List is Empty
        head=createNode(data);
    else{
       while(temp->next!=NULL) //to move to last node in the list
            temp=temp->next;
       nn=createNode(data);
       temp->next=nn;
    }
return head;
}
NODE* insertMid(NODE* head,int data,int pos){
    NODE *nn,*temp=head;
    int i=1;//i pos of temp pointer
    if(head==NULL) //List is Empty
        head=createNode(data);
    else{
        while(i<pos-1 && temp->next!=NULL){
            i++;
            temp=temp->next;
        }
        nn=createNode(data);
        nn->next=temp->next;
        temp->next=nn;
    }
    return head;
}

int isEmpty(NODE* head){
    if(head==NULL)
        return 1;
    return 0;
}

int isOneElement(NODE* head){
    if(head->next==NULL)
        return 1;
    return 0;
}
NODE* deleteB(NODE *head){
    NODE *temp=head;
    head=head->next;
    temp->next=NULL;
    free(temp);
    return head;
}

NODE* deleteM(NODE *head,int pos){
    NODE *temp=head,*temp1;
    for(int i=1;i<pos-1;i++)
        temp=temp->next;
    temp1=temp->next;
    temp->next=temp1->next;
    temp1->next=NULL;
    free(temp1);
    return head;
}
NODE* deleteE(NODE *head){
    NODE *temp=head,*temp1;
    while(temp->next->next!=NULL)//to move temp point to l2nd last element
        temp=temp->next;
    temp1=temp->next;
    temp->next=NULL;
    free(temp1);
    return head;
}

void display(NODE *head){
    NODE *temp=head;
    if(!isEmpty(head)){
        printf("\n");
        while(temp->next!=head){
            printf("%d->",temp->data);
            temp=temp->next;
        }
        printf("NULL");
    }
}
int search(NODE *head,int data){
    NODE *temp=head;
    int i=1;
    while(temp!=NULL || temp->data!=data){
        temp=temp->next;
        i++;
    }
    if(temp==NULL){
        return 0;
    }
    if(temp->data==data){
        return i;
    }
}
int main(){
    int data,ch,cont,pos,n;
    NODE *head=NULL;
    printf("\nEnter the First data:");
    scanf("%d",&data);
    head=createNode(data);
    do{
    printf("\n Enter your Choice:");
    printf("\n1. Insert_start \n2. Insert_mid \n3. Insert_End \n7.display");
    scanf("%d",&ch);
    switch(ch){
        case 1:
            printf("\nEnter the data to be inserted:");
            scanf("%d",&data);
            head=insertStart(head,data);
            display(head);
            break;
        case 2:
            printf("\nEnter the data to be inserted:");
            scanf("%d",&data);
            printf("\nEnter the position data to be inserted:");
            scanf("%d",&pos);
            head=insertMid(head,data,pos);
            display(head);
            break;
        case 3:
            printf("\nEnter the data to be inserted:");
            scanf("%d",&data);
            head=insertEnd(head,data);
            display(head);
            break;
        case 4://Deleting at the Start
            if(isEmpty(head)){
                printf("\nList is Empty;Cannot perform deletion");
                break;
            }
            else if(isOneElement(head)){
                free(head);
                head=NULL;
            }
            else{
                head=deleteB(head);
                display(head);
            }
            break;
        case 5://delete at Mid
            if(isEmpty(head)){
                printf("\nList is Empty;Cannot perform deletion");
                break;
            }
            else if(isOneElement(head)){
                free(head);
                head=NULL;
            }
            else{
                printf("\nEnter the position data to be deleted:");
                scanf("%d",&pos);
                head=deleteM(head,pos);
                display(head);
            }
            break;
        case 6://Deleting at the End
            if(isEmpty(head)){
                printf("\nList is Empty;Cannot perform deletion");
                break;
            }
            else if(isOneElement(head)){
                free(head);
                head=NULL;
            }
            else{
                head=deleteE(head);
                display(head);
            }
            break;
        case 7:
            printf("Enter the data to be searched");
            scanf("%d",&data);
            n=search(head,data);
            if(n)
                printf("\nThe data is found at %dth position",n);
            else
                printf("\nThe data Not found in the List");
        default:
            exit(0);
    }
    printf("\nDo you want to cont... (1/0)");
    scanf("%d",&cont);
    }while(cont);
}
