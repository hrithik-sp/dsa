#include<stdio.h>
#include<stdlib.h>
#define MAX 10
struct arrList{
    int last;
    int arr[MAX];
};

struct arrList* append(struct arrList *p,int data){
    if(p->last<MAX){
        p->last++;
        p->arr[p->last]=data;
    }
    else
        printf("\nThe List is full");
    return p;
};
void display(struct arrList *p){
    if(p->last==-1)//Empty Condition
    {
        printf("\List is empty");
    }
    else{
        printf("\n");
        for(int i=0;i<=p->last;i++){
           printf("%d ",p->arr[i]);
        }
    }
}
struct arrList* deleteL(struct arrList *p){
    if(p->last==-1)//Empty Condition
        printf("\nArray is empty;Cannot perform deletion");
    else{
        p->last--;
        return p;
    }
}
int main(){
    int ch,cont,data;
    struct arrList *p;
    p=(struct arrList*)malloc(sizeof(struct arrList));
    //initialize
    p->last=-1; //array is empty
    do{
    printf("\n Enter your Choice:");
    printf("\n1. append \n2. delete \n3. display");
    scanf("%d",&ch);
    switch(ch){
        case 1:
            printf("\nEnter the data to be inserted:");
            scanf("%d",&data);
            p=append(p,data);
            display(p);
            break;
        case 2:
            p=deleteL(p);
            display(p);
            break;
        case 3:
            display(p);
            break;
        default:
            exit(0);
    }
    printf("\nDo you want to Cont...(1/0):");
    scanf("%d",&cont);
    }while(cont);
}
