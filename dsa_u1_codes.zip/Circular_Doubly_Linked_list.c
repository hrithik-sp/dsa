#include<stdio.h>
#include<stdlib.h>

typedef struct node{
    int data;
    struct node *prev;
    struct node *next;
}NODE;

typedef struct header{
    int count;
    NODE *head;
    NODE *last;
}HEADER;
HEADER* init(HEADER *p){ // Used to initialize Header node
    p=(HEADER*)malloc(sizeof(HEADER));
    p->count=0;
    p->head=NULL;
    p->last=NULL;
    return p;
}
NODE* createNode(int data){ //Used for creating a node in LL
    NODE *nn=(NODE*)malloc(sizeof(NODE));
    nn->data=data;
    nn->prev=NULL;
    nn->next=NULL;
    return nn;
}
void insertB(HEADER *p,int data){
    NODE *temp=p->head;
    //First Node
    if(p->count==0){ //p->head==NULL
        p->head=createNode(data);
        p->last=p->head;
        p->last->next=p->head;//Changes
        p->head->prev=p->last;//changes
    }
    else{
        temp=createNode(data);
        temp->next=p->head;
        p->head->prev=temp;
        p->head=temp;
        p->last->next=p->head;
        p->head->prev=p->last;
    }
    p->count++;
    //return p;
}
HEADER* insertE(HEADER *p,int data){
    NODE *temp;
    if(p->count==0){
        p->head=createNode(data);
        p->last=p->head;
        p->last->next=p->head;//changes
        p->head->prev=p->last;//changes
    }
    else{
        temp=createNode(data);
        temp->prev=p->last;
        p->last->next=temp;
        p->last=temp;
        p->last->next=p->head;//changes
        p->head->prev=p->last;//changes
    }
    p->count++;
    return p;
}
HEADER* insertM(HEADER *p,int data,int pos){
    NODE *temp=p->head,*nn,*temp1;
    if(p->count==0){
        p->head=createNode(data);
        p->last=p->head;
        p->last->next=p->head;
        p->head->prev=p->last;
    }
    else if(pos>p->count){
        p=insertE(p,data);
    }
    else{
        nn=createNode(data);
        for(int i=1;i<pos-1;i++)
            temp=temp->next;
        temp1=temp->next;
        nn->prev=temp;
        nn->next=temp1;
        temp->next=nn;
        temp1->prev=nn;
    }
    p->count++;
    return p;
}
HEADER* deleteB(HEADER *p){
    NODE *temp=p->head;
    if(p->count==0){
        printf("\nThe list is empty;Cannot delete");
    }
    else if(p->count==1){ //DLL:p->head==p->last // CDLL:p->head->next==p->head
        p->head=p->last=NULL;
        temp->next=NULL; //changes
        temp->prev=NULL; //changes
        free(temp);
        p->count--;
    }
    else{
        p->head=p->head->next;
        temp->next=NULL;
        //p->head->prev=NULL;//changes
        p->last->next=p->head;//changes
        p->head->prev=p->last;//changes
        free(temp);
        p->count--;
    }
    return p;
}
HEADER* deleteE(HEADER *p){
    NODE *temp=p->last;
    if(p->count==0){
        printf("\nThe list is empty;Cannot delete");
    }
    else if(p->count==1){ //p->head==p->last // CDLL: p->head->next==p->head
        p->head=NULL;
        p->last=NULL;
        temp->next=NULL; //changes
        temp->prev=NULL; //changes
        free(temp);
        p->count--;
    }
    else{
        p->last=p->last->prev;
        p->last->next=p->head;//Changes:From NULL to p->head
        p->head->prev=p->last;//Changes: add
        temp->prev=NULL;
        temp->next=NULL;
        free(temp);
        p->count--;
    }
    return p;
}
HEADER* deleteM(HEADER *p,int pos){
    NODE *temp=p->head,*temp1;
    if(pos>=p->count)
        p=deleteE(p);
    else if(pos==1)
        p=deleteB(p);
    else{
        for(int i=1;i<pos-1;i++)
            temp=temp->next;
        temp1=temp->next;
        temp1->next->prev=temp;
        temp->next=temp1->next;
        temp1->prev=NULL;
        temp1->next=NULL;
        free(temp1);
        p->count--;
    }
    return p;
}
void display(HEADER *p){
    NODE *t=p->head;
    if(p->head==NULL){
        printf("The list is Empty");
        return;
    }
    while(t->next!=p->head){//for(int i=1;i<=p->count;i++)//Change
        printf("<->%d",t->data);
        t=t->next;
    }
    printf("<->%d",t->data);
}
int main(){
    int ch,cont,data,pos;
    HEADER *p;
    p=init(p);
    do{
    printf("\n Enter your Choice:");
    printf("\n1. Insert_start \n2. Insert_mid \n3. Insert_End \n4.Delete_Start \n5.Delete_Mid \n6.Delete_End");
    scanf("%d",&ch);
    switch(ch){
        case 1:
            printf("\nEnter the data to be inserted:");
            scanf("%d",&data);
            insertB(p,data);
            display(p);
            break;
        case 2:
            printf("\nEnter the data to be inserted:");
            scanf("%d",&data);
            printf("\nEnter the position of data to be inserted:");
            scanf("%d",&pos);
            insertM(p,data,pos);
            display(p);
            break;
        case 3:
            printf("\nEnter the data to be inserted:");
            scanf("%d",&data);
            p=insertE(p,data);
            display(p);
            break;
        case 4:
            p=deleteB(p);
            display(p);
            break;
        case 5:
            printf("\nEnter the position of the data to be deleted:");
            scanf("%d",&pos);
            p=deleteM(p,pos);
            display(p);
            break;
         case 6:
            p=deleteE(p);
            display(p);
            break;
         default:
            exit(0);
        }
    printf("\nDo you want to Continue....(1/0)");
    scanf("%d",&cont);
    }while(cont);
}
