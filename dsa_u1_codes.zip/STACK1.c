//C. Vishwa - 3rd semester - Batch 2023-27
// STACK is a linear data structure which follows Last In First Out (LIFO) principle.
// It is a collection of elements with the last element inserted at the top of the stack.
// Operations that can be performed on the stack are:
// 1. push(element) -> inserts an element to the stack
// 2. pop() -> removes the topmost element from the stack and returns it
// 3. peek() -> returns the topmost element of the stack
// 4. display() -> displays all the elements of the stack
// We have 2 conditions for the stack to be full and empty.
// If the stack is full, then the push operation will not be performed. This condition is also known as overflow condition.
// If the stack is empty, then the pop operation will not be performed. This condition is also known as underflow condition.

//Array implementation of STACK
# include <stdio.h>
# include <stdlib.h>
# define SIZE 10//size of the stack

typedef struct stack
{
    int top;//represents the top of the stack (index of the last element)
    int arr[SIZE];
}STACK;

STACK *init(STACK *s)//initializes the stack (creates a new stack/structure)
{
    s=(STACK *)malloc(sizeof(STACK));//dynamically allocate memory for the stack
    s->top = -1;
    return s;
}

void push(STACK *s,int data)//push (insert) an element to the stack
{
    if(s->top==SIZE-1)//if the stack is full (overflow condition)
        printf("Stack is full\n");
    else
    {
        s->top++;//increment the top of the stack
        s->arr[s->top]=data;//push the element to the stack
        printf("Element pushed to the stack\n");
    }
}

void pop(STACK *s)//pop (remove) the topmost element from the stack
{
    if(s->top==-1)//if the stack is empty (underflow condition)
        printf("Stack is empty\n");
    else
    {
        printf("Element popped from the stack is %d\n",s->arr[s->top]);//pop the topmost element from the stack
        s->top--;//decrement the top of the stack
    }
}

void peek(STACK *s)//peek (view) the topmost element of the stack
{
    if(s->top==-1)//if the stack is empty (underflow condition)
        printf("Stack is empty\n");
    else
        printf("Topmost element of the stack is %d\n",s->arr[s->top]);//peek the topmost element of the stack
}

void display(STACK *s)//display all the elements of the stack
{
    printf("\nThe Stack is: ");//display the stack
    int t=s->top;//temporary variable to traverse the stack
    while(t!=-1)//check if the stack is empty
    {
        printf("%d ",s->arr[t--]);//display all the elements of the stack
    }
    printf("\n");
}

int main()
{
    STACK *s;
    s=init(s);
    int choice;
    while(1)
    {
        printf("Enter your choice\n");
        printf("1. Push\n");
        printf("2. Pop\n");
        printf("3. Peek\n");
        printf("4. Display\n");
        printf("5. Exit\n");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:
                printf("Enter the element to be pushed\n");
                scanf("%d",&choice);
                push(s,choice);
                break;
            case 2:
                pop(s);
                break;
            case 3:
                peek(s);
                break;
            case 4:
                display(s);
                break;
            case 5:
                exit(0);
                break;
            default:
                printf("Invalid choice\n");
                break;
        }
    }
    return 0;
}