#include<stdio.h>
#include<stdlib.h>

typedef struct node{
    int data;
    struct node *next;//points to previous node address
}NODE;
NODE* createNode(int data){
    NODE *nn;
    nn=(NODE*)malloc(sizeof(NODE));
    nn->data=data;
    nn->next=NULL;
    return nn;
}
void display(NODE **top){
    NODE *t=*top;
    while(t!=NULL){
        printf("\n    %d",t->data);
        t=t->next;
    }
}
void push(NODE **top,int data){
    NODE *nn;
    nn=createNode(data);
    nn->next=*top;
    *top=nn;
    display(top);
}
void pop(NODE **top){
    NODE *temp=*top;
    if(*top!=NULL){
        *top=(*top)->next;
        temp->next=NULL;
        free(temp);
        display(top);
    }
    else
        printf("The stack is empty");
}

int main(){
    NODE *top=NULL;
    int data;
    printf("\nEnter the data to be inserted:");
    scanf("%d",&data);
    push(&top,data);
     push(&top,20);
     push(&top,30);
     pop(&top);
     pop(&top);
     pop(&top);
     pop(&top);
}
