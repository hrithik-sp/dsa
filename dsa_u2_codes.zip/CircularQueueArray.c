#include<stdio.h>
#define SIZE 3

typedef struct queue{
    int array[SIZE];
    int front;
    int rear;
}QUEUE;
QUEUE* init(QUEUE *q){
    q=(QUEUE*)malloc(sizeof(QUEUE));
    q->front=-1;
    q->rear=-1;
}
int isFull(QUEUE *q){
    if((q->front==0 && q->rear>=SIZE-1)||(q->front==(q->rear)+1))
        return 1;
    return 0;
}
int isEmpty(QUEUE *q){
    if(q->rear==q->front && q->front==-1)
        return 1;
    return 0;
}
int isOneElement(QUEUE *q){
    if(q->rear==q->front && q->front!=-1)
        return 1;
    return 0;
}
void enqueue(QUEUE *q,int data){
    if(isFull(q)){
        printf("\n The queue is full");
        }
    else if(isEmpty(q)){
        q->front=0;
        q->rear=0;
        q->array[q->rear]=data;
    }//Changes
    else if(q->rear==SIZE-1 && q->front!=0){
        q->rear=0;
        q->array[q->rear]=data;
    }//
    else{
        (q->rear)++;
        q->array[q->rear]=data;
        }
}
void dequeue(QUEUE *q){
    if(isEmpty(q)){
        printf("\nThe Queue is empty, cannot delete");
    }
    else if(isOneElement(q)){
        q->front=-1;
        q->rear=-1;
    }//changes
    else if(q->front==SIZE-1 && q->rear<q->front){
        q->front=0;
    }//
    else{
        (q->front)++;
    }
}
void display(QUEUE *q){
    if(!isEmpty(q)){
        printf("\n");
        if(q->front<=q->rear){
            for(int i=q->front;i<=q->rear;i++)
                printf("%d ",q->array[i]);
        }
        else{//r<f
            for(int i=q->front;i<=SIZE-1;i++)
                printf("%d ",q->array[i]);
            for(int i=0;i<=q->rear;i++)
                printf("%d ",q->array[i]);
        }
    }
    else
        printf("\nThe queue is empty");
}
int main(){
    QUEUE *q;
    q=init(q);
    enqueue(q,10);
    display(q);
    enqueue(q,20);
    display(q);
    enqueue(q,30);
    display(q);
    enqueue(q,40);
    display(q);
    dequeue(q);
    display(q);
    enqueue(q,40);
    display(q);
    dequeue(q);
    display(q);
    dequeue(q);
    display(q);
    dequeue(q);
    display(q);
    dequeue(q);
    display(q);
    return 0;

}

