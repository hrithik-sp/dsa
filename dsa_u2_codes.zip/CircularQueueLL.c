#include<stdio.h>
#include<stdlib.h>

typedef struct node{
    int data;
    struct node *next;
}NODE;

typedef struct queue{
    NODE *rear;
    NODE *front;
}QUEUE;

QUEUE* init(QUEUE *q){
    q=(QUEUE*)malloc(sizeof (QUEUE));
    q->front=NULL;
    q->rear=NULL;
    return q;
}
int isEmpty(QUEUE* q){
    if((q->rear==q->front) && (q->front==NULL))
        return 1;
    return 0;
}
int isOneElement(QUEUE* q){
    if((q->rear==q->front) && (q->front!=NULL))
        return 1;
    return 0;
}
NODE* createNode(int data){
    NODE *nn=(NODE*)malloc(sizeof(NODE));
    nn->data=data;
    nn->next=NULL;
    return nn;
}
void enqueue(QUEUE *q,int data){
    NODE *nn;
    nn=createNode(data);
    if(isEmpty(q)){
        q->front=nn;
        q->rear=nn;
        q->rear->next=q->front;//changes
    }
    else{
        q->rear->next=nn;
        q->rear=nn;//=q->rear->next;
        q->rear->next=q->front;//changes
    }
}
void dequeue(QUEUE *q){
    NODE *t=q->front;
    if(isEmpty(q)){
        printf("\nThe queue is Empty.");
    }
    else if(isOneElement(q)){
        q->rear=NULL;
        q->front=NULL;
        free(t);
    }
    else{
        q->front=q->front->next;
        t->next=NULL;
        free(t);
        q->rear->next=q->front;//changes
    }
}
void display(QUEUE *q){
    NODE *t=q->front;
    if(!isEmpty(q)){
            printf("\n");
        while(t!=q->rear){//changes
            printf("%d ",t->data);
            t=t->next;
        }
        printf("%d ",t->data);//changes
    }
}
int main(){
    QUEUE *q=NULL;
    q=init(q);
    enqueue(q,10);
        display(q);
    enqueue(q,20);
        display(q);
    enqueue(q,30);
        display(q);
    dequeue(q);
        display(q);
    dequeue(q);
        display(q);
    dequeue(q);
        display(q);
    dequeue(q);
        display(q);
    return 0;
}
