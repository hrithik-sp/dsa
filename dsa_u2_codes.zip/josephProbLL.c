#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
};

struct Node* createNode(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

// Function to create a circular linked list of size n
struct Node* createCircularList(int n) {
    struct Node* head = createNode(1);
    struct Node* prev = head;
    for (int i = 2; i <= n; i++) {
        struct Node* newNode = createNode(i);
        prev->next = newNode;
        prev = newNode;
    }
    prev->next = head;  // Complete the circle
    return head;
}

// Function to solve the Josephus problem
int josephus(int n, int k) {
    struct Node* head = createCircularList(n);
    struct Node* prev = NULL;
    struct Node* curr = head;
    
    while (curr->next != curr) {  // Loop until one node remains
        for (int count = 1; count < k; count++) {
            prev = curr;
            curr = curr->next;
        }
        // Remove the k-th node
        prev->next = curr->next;
        printf("%d \n", curr->data);
        free(curr);
        curr = prev->next;
    }
    int winner = curr->data;
    free(curr);
    return winner;
}

int main() {
    int n, k;
    printf("Enter the number of people (n): ");
    scanf("%d", &n);
    printf("Enter the step size (k): ");
    scanf("%d", &k);

    int winner = josephus(n, k);
    printf("%d is saved\n", winner);
    
    return 0;
}
