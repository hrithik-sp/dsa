#include <stdio.h>
#include <stdlib.h>

#define MAX 100

typedef struct {
    int items[MAX];
    int front, rear;
} CircularQueue;

void initQueue(CircularQueue *q) {
    q->front = -1;
    q->rear = -1;
}

int isFull(CircularQueue *q) {
    return (q->rear + 1) % MAX == q->front;
}

int isEmpty(CircularQueue *q) {
    return q->front == -1;
}

void enqueue(CircularQueue *q, int value) {
    if (isFull(q))
        return;
    if (isEmpty(q))
        q->front = 0;
    q->rear = (q->rear + 1) % MAX;
    q->items[q->rear] = value;
}

int dequeue(CircularQueue *q) {
    if (isEmpty(q))
        return -1;
    int value = q->items[q->front];
    if (q->front == q->rear)
        q->front = q->rear = -1;
    else
        q->front = (q->front + 1) % MAX;
    return value;
}

int josephus(int n, int k) {
    CircularQueue q;
    initQueue(&q);
    for (int i = 1; i <= n; i++)
        enqueue(&q, i);
    while (q.front != q.rear) {
        for (int i = 0; i < k - 1; i++)
            enqueue(&q, dequeue(&q));
        dequeue(&q);
    }
    return dequeue(&q);
}

int main() {
    int n, k;
    printf("Enter the number of people (n): ");
    scanf("%d", &n);
    printf("Enter the step count (k): ");
    scanf("%d", &k);
    printf("The last person standing is %d\n", josephus(n, k));
    return 0;
}
