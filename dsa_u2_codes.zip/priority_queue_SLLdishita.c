#include<stdio.h>
#include<stdlib.h>

typedef struct node {
    int data;
    int priority;
    struct node *next;
} NODE;

typedef struct queue {
    NODE* rear;
    NODE* front;
} QUEUE;

QUEUE* init(QUEUE* q) {
    q = (QUEUE*)malloc(sizeof(QUEUE));
    q->front=NULL;
    q->rear=NULL;
    return q;
}

int isEmpty(QUEUE* q){
    if(q->front==NULL && q->rear==NULL)
        return 1;
    else 
        return 0;
}

int isOneElement(QUEUE* q){
    if(q->front==q->rear && q->front!=NULL)
        return 1;
    else
        return 0;
}

NODE* createNode(int data, int priority){
    NODE* nn=(NODE*)malloc(sizeof(NODE));
    nn->data=data;
    nn->priority=priority;
    nn->next=NULL;
    return nn;
}

void enqueue(QUEUE* q, int data, int priority){
    NODE* nn=createNode(data, priority);
    
    if (isEmpty(q)) {
        q->front=nn;
        q->rear=nn;
    } 
    else if (q->front->priority <=priority){
        nn->next=q->front;
        q->front=nn;
    } 
    else {
        NODE* temp=q->front;
        NODE* prev=NULL;
        
        while (temp!=NULL && temp->priority>=priority){
            prev=temp;
            temp=temp->next;
        }
        
        if (temp==NULL){
            prev->next=nn;
            q->rear=nn;
        } 
        else{
            nn->next=temp;
            prev->next=nn;
        }
    }
}

void dequeue(QUEUE* q){
    if (isEmpty(q)){
        printf("\nQueue is empty\n");
        return;
    }
    
    NODE* temp=q->front;
    
    if (isOneElement(q)){
        q->front=NULL;
        q->rear=NULL;
    } 
    else{
        q->front=q->front->next;
    }
    free(temp);
}

void display(QUEUE* q){
    if (isEmpty(q)){
        printf("\nQueue is empty\n");
    }
    NODE* temp=q->front;
    while (temp!=NULL){
        printf("%d [%d]     ",temp->data,temp->priority);
        temp=temp->next;
    }
}

int main() {
    QUEUE *q=NULL;
    q=init(q);
    int choice,data,priority;

    do {
        printf("\nEnter your choice:\n1.Enqueue\n2.Dequeue\n3.Display\n4.Exit\n");
        scanf("%d", &choice);
        
        switch (choice){
            case 1:
                printf("\nEnter the data along with priority to be inserted: ");
                scanf("%d %d", &data, &priority);
                enqueue(q, data, priority);
                break;
            case 2:
                dequeue(q);
                break;
            case 3:
                display(q);
                break;
            case 4:
                exit(0);
            default:
                printf("Invalid choice\n");
                break;
        }
    }while(choice);

    return 0;
}
