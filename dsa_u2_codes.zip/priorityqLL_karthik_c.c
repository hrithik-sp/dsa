#include<stdio.h>
#include<stdlib.h>
typedef struct node{
    int data;
    int priority;
    struct node * next;
}NODE;
typedef struct queue{
    NODE * rear;
    NODE * front;
}QUEUE;
QUEUE * init(QUEUE * q){
    q=(QUEUE *)malloc(sizeof(QUEUE));
    q->front=NULL;
    q->rear=NULL;
    return q;
}
int isEmpty(QUEUE * q){
    if((q->front==NULL)){
        return 1;
    }
    return 0;
}
int isOneElement(QUEUE * q){
    if((q->rear==q->front)&&(q->front!=NULL)){
        return 1;
    }
    return 0;
}
NODE * createnode(int data,int priority){
    NODE * nn=(NODE *)malloc(sizeof(NODE));
    nn->data=data;
    nn->priority=priority;
    nn->next=NULL;
    return nn;
}
void enqueue(QUEUE *q,int data,int priority){
    NODE *nn;
    NODE * t=q->front;
    NODE *prev=NULL;
    nn=createnode(data,priority);
    if(isEmpty(q)) {
        q->front=nn;
        q->rear=nn;
        //q->rear->next=NULL;
    }
    else if(q->front->priority<=priority){
        NODE * temp=q->front;
        q->front=nn;
        nn->next=temp;
    }
    else if(q->rear->priority>=priority){
        NODE * temp1=q->rear;
        q->rear=nn;
        nn->next=NULL;
        temp1->next=nn;
    }
    else{
        while(t->next!=NULL && t->priority>=priority){
            prev=t;
            t=t->next;
        }
        prev->next=nn;
        nn->next=t;
    }
}

void display(QUEUE *q){
    NODE *t=q->front;
    if(!isEmpty(q)){
        while(t->next!=NULL){
            printf("%d %d\n",t->data,t->priority);
            t=t->next;
        }
        printf("%d %d\n",t->data,t->priority);
    }
}
int main() {
    QUEUE *q;
    q = init(q);
    enqueue(q, 20,1);
    enqueue(q, 30,5);
    enqueue(q, 40,6);
    display(q);
}