#include<stdio.h>
#include<stdlib.h>
#define SIZE 5

typedef struct node{
    int data;
    int priority;
}NODE;

typedef struct queue{
    int front;
    int rear;
    NODE array[SIZE];
}QUEUE;
QUEUE* init(QUEUE *q){
    q=(QUEUE*)malloc(sizeof(QUEUE));
    q->front=-1;
    q->rear=-1;
    return q;
}
int isEmpty(QUEUE* q){
    if(q->front==q->rear && q->front==-1)
        return 1;
    return 0;
}
int isFull(QUEUE* q){
    if(q->rear>=SIZE-1)
        return 1;
    return 0;
}
int isOneElement(QUEUE* q){
    if(q->front==q->rear && q->front!=-1)
        return 1;
    return 0;
}
void enqueue(QUEUE *q,int data,int priority){
    int t1=q->front,t2=q->rear;
    if(isFull(q)){
        printf("\nThe queue is Full.");
    }
    else if(isEmpty(q)){
        q->front=0;
        q->rear=0;
        q->array[q->rear].data=data;
        q->array[q->rear].priority=priority;
    }
    else{
        while(q->array[t1].priority>=priority && t1<=q->rear){
            t1++;
        }
        while(t2>=t1){
            q->array[t2+1]=q->array[t2];
            //q->array[t2+1].data=q->array[t2].data;
            //q->array[t2+1].priority=q->array[t2].priority;
            t2--;
        }
        q->array[t1].data=data;
        q->array[t1].priority=priority;
        (q->rear)++;
    }
}
void display(QUEUE *q){
    if(!isEmpty(q)){
        for(int i=q->front;i<=q->rear;i++){
            printf("\n[%d]%d,%d",i,q->array[i].data,q->array[i].priority);
        }
    printf("\n********");
    }
    else
        printf("\nThe Queue is Empty");
}
void dequeue(QUEUE *q){
    if(isEmpty(q)){
        printf("\nThe queue is empty");
    }
    else if(isOneElement(q)){
        q->rear=-1;
        q->front=-1;
    }
    else{
        (q->front)++;
    }
}

int main(){
    QUEUE *q;
    q=init(q);
    enqueue(q,10,2);
    display(q);
    enqueue(q,15,1);
    display(q);
    enqueue(q,20,4);
    display(q);
    enqueue(q,30,3);
    display(q);
    dequeue(q);
    display(q);
    dequeue(q);
    display(q);
    dequeue(q);
    display(q);
    dequeue(q);
    display(q);
    return 0;
}
